# Esercizio 1

## Indice
1. [Esercizio](#Esercizio)
  * [Testo esercizio](#Testo-esercizio)
2. [Svolgimento](#Svolgimento)    
  * [Funzionamento](#Funzionamento)
  * [Versione](#Versione)
      * [Progetto](#Progetto)
      * [Emulatore](#Emulatore)


# Esercizio
## Testo esercizio
Creare un LinearLayout con 5 TextView.\
Sono tutte vuote tranne una.\
Al click di un Button, il testo si sposta in alto (a rotazione).

# Svolgimento
## Funzionamento
![Alt Text](https://media.giphy.com/media/W6oP2xVefdArFHcXvB/giphy.gif)

## Versione
### Progetto
Andoird studio 3.6.2
API 21: Android 5.0 Lollipop 

### Emulatore
Pixel 2 API 28 Andoird 9.0 (Google APIs) x86_64