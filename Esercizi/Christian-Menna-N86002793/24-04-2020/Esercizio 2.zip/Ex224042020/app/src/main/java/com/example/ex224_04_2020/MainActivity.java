package com.example.ex224_04_2020;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void chgpos(android.view.View v){
        TextView idT2 = findViewById(R.id.T2);
        MarginLayoutParams param = (MarginLayoutParams) idT2.getLayoutParams();
        int random = new Random().nextInt(500);
        param.setMarginStart(random);
        param.setMargins(0, random, 0, 0);
        idT2.setLayoutParams(param);
    }
}
