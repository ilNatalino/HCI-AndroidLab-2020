package com.example.esercizio324_04_2020;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addRadio(View v){
        RadioGroup rg = findViewById(R.id.rg1);
        int count = rg.getChildCount();
        if (count < 15){
            /*for (int i=1; i<=count; i++){
                RadioButton r = (RadioButton) rg.getChildAt(i-1);
                r.setChecked(false);
            }*/
        RadioButton newc = new RadioButton(rg.getContext());
        rg.addView(newc);
        newc.setText("BUTTON " + count);
        //newc = (RadioButton) rg.getChildAt(count);
        newc.setChecked(true);
        }
        else {
            Button b = findViewById(R.id.button);
            AlertDialog.Builder builder = new AlertDialog.Builder(b.getContext());
            builder.setTitle("Impossibile eseguire l'azione");
            builder.setMessage("Ci sono troppi RadioButton!");
            builder.show();
        }
    }
}
