package com.example.ex124_04_2020;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void changetxt(android.view.View v){
        TextView t1ID = findViewById(R.id.textView7);
        TextView t2ID = findViewById(R.id.textView8);
        TextView t3ID = findViewById(R.id.textView9);
        TextView t4ID = findViewById(R.id.textView10);
        TextView t5ID = findViewById(R.id.textView11);
        float t1X = t1ID.getX();
        float t1Y = t1ID.getY();
        float t2X = t2ID.getX();
        float t2Y = t2ID.getY();
        float t3X = t3ID.getX();
        float t3Y = t3ID.getY();
        float t4X = t4ID.getX();
        float t4Y = t4ID.getY();
        float t5X = t5ID.getX();
        float t5Y = t5ID.getY();
        t1ID.setX(t5X);
        t1ID.setY(t5Y);
        t2ID.setX(t1X);
        t2ID.setY(t1Y);
        t3ID.setX(t2X);
        t3ID.setY(t2Y);
        t4ID.setX(t3X);
        t4ID.setY(t3Y);
        t5ID.setX(t4X);
        t5ID.setY(t4Y);
    }
}
