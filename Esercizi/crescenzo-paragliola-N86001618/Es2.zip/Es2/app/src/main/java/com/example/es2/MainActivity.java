package com.example.es2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button pizzaBTN, linkBTN;
    private TextView T1;
    private RadioGroup rGroup;
    private int nFigli;
    private RadioButton radioButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        T1 = findViewById(R.id.t1);

        rGroup = findViewById(R.id.radio);

        pizzaBTN = findViewById(R.id.buttonPizza);
        pizzaBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Don't you dare, you godless heathen.", Toast.LENGTH_LONG).show();
                ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) T1.getLayoutParams();
                params.setMargins(0, 500, 0, 0);
                T1.setLayoutParams(params);
            }
        });

        linkBTN = findViewById(R.id.add);
        linkBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                rGroup = findViewById(R.id.radioGroup);
                nFigli = rGroup.getChildCount();

                radioButton = new RadioButton(rGroup.getContext());

                radioButton.setText("Friarielli!");

                if(nFigli > 0){
                    RadioButton ultimoFiglio = (RadioButton) rGroup.getChildAt(nFigli - 1);
                    ultimoFiglio.setChecked(false);
                }

                // Toggle the last radio button
                radioButton.setChecked(true);
                rGroup.addView(radioButton);

            }
        });
    }
}
