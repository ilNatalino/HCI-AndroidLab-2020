package com.example.hci_2304_es1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button swapBTN, swapBTN2;
    private TextView t1,t2,t3,t4,t5;
    private float AuxX, AuxY; /// VARIABILI CHE MEMORIZZANO LA POSIZIONE INIZIALE, SERVONO ALLO SWAP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        t3 = findViewById(R.id.t3);
        t4 = findViewById(R.id.t4);
        t5 = findViewById(R.id.t5);

        /* INDIRIZZAMENTO AL BOTTONE*/
        swapBTN = findViewById(R.id.swapButton);
        swapBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence Aux = t1.getText();
                t1.setText(t2.getText());
                t2.setText(t3.getText());
                t3.setText(t4.getText());
                t4.setText(t5.getText());
                t5.setText(Aux);
            }
        });

        swapBTN2 = findViewById(R.id.swapButton2);
        swapBTN2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence Aux = t5.getText();
                t5.setText(t4.getText());
                t4.setText(t3.getText());
                t3.setText(t2.getText());
                t2.setText(t1.getText());
                t1.setText(Aux);
            }
        });

    }

}
